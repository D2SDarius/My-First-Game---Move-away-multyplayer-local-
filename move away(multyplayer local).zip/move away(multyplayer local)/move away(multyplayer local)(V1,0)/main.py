#code e e e : ) D2STeam
import turtle
import os
#screen
wn = turtle.Screen()
wn.bgcolor("gray")
wn.title("move away")

#player1
player = turtle.Turtle()
player.color("orange")
player.shape("square")
player.pendown()
player.speed(0)
player.setposition(0 , 0)
player.setheading(90)

playerspeed = 15

#definitia fiecarai miscari
def move_left():
    x = player.xcor()
    x -= playerspeed
    if x < -500:
        x = - 280
    player.setx(x)

def move_down():
    y = player.ycor()
    y -= playerspeed
    if y < -500:
        y = - 280
    player.sety(y)

def move_up():
    y = player.ycor()
    y += playerspeed
    if y < -500:
        y = 280
    player.sety(y)

def move_right():
    x = player.xcor()
    x += playerspeed
    if x > 500:
        x = 280
    player.setx(x)
#definitia schimbari de culori
def switch_color1a():
  player.color("red")


def switch_color2a():
  player.color("orange")



#tastele pentru player1
turtle.listen()
turtle.onkey(move_left, "Left")
turtle.onkey(move_right, "Right")
turtle.onkey(move_down, "Down")
turtle.onkey(move_up, "Up")
turtle.onkey(switch_color1a, "5")
turtle.onkey(switch_color2a, "6")


#player2
player2 = turtle.Turtle()
player2.color("black")
player2.shape("triangle")
player2.penup()
player2.speed(0)
player2.setposition(0 , 300)
player2.setheading(90)
player2.pendown()
player2speed = 15

#definiti de miscare de la player2

def move_right2():
    x = player2.xcor()
    x -= player2speed
    if x < -500:
        x = - 280
    player2.setx(x)

def move_down2():
    y = player2.ycor()
    y -= player2speed
    if y < -500:
        y = - 280
    player2.sety(y)

def move_up2():
    y = player2.ycor()
    y += player2speed
    if y < -500:
        y = 280
    player2.sety(y)

def move_left2():
    x = player2.xcor()
    x += player2speed
    if x > 500:
        x = 280
    player2.setx(x)

#definiti ale culori pentru player2

def switch_color1b():
  player2.color("white")


def switch_color2b():
  player2.color("black")

#tastele pentru player2

turtle.listen()
turtle.onkey(move_right2, "a")
turtle.onkey(move_left2, "d")
turtle.onkey(move_down2, "s")
turtle.onkey(move_up2, "w")
turtle.onkey(switch_color1b, "1")
turtle.onkey(switch_color2b, "2")





#commanda care va sti condul ca este gata (trebe pus mereu la sfarsit atunci cand faci coding in python cu turtle )
turtle.done()